from rest_framework import permissions, viewsets
from rest_framework.exceptions import MethodNotAllowed
from django.db.models import F

from accounts.permissions import IsReservationRole, IsFinanceRole, IsReservationEditorOrReadOnlyIfLocked
from inventory.models import HotelRoom
from .models import (
    ExcursionBooking,
    ExcursionService,
    FlightTicket,
    HotelBooking,
    Reservation,
    Tourist,
    TransferService
)
from .serializers import (
    ExcursionBookingSerializer,
    ExcursionServiceSerializer,
    FlightTicketSerializer,
    HotelBookingSerializer,
    ReservationSerializer,
    TouristSerializer,
    TransferServiceSerializer,
)


class PreventHardDeleteMixin:
    def destroy(self, request, *args, **kwargs):
        raise MethodNotAllowed(
            "DELETE", 
            detail="Hard deletion is disabled. Please change the status to CANCELED via PATCH/PUT."
        )


class AdminReservationViewSet(PreventHardDeleteMixin, viewsets.ModelViewSet):
    queryset = Reservation.objects.all().order_by("-created_at")
    serializer_class = ReservationSerializer
    permission_classes = (IsReservationRole, IsReservationEditorOrReadOnlyIfLocked)


class ClientReservationViewSet(viewsets.ModelViewSet):
    queryset = Reservation.objects.all().order_by("-created_at")
    serializer_class = ReservationSerializer
    permission_classes = (permissions.IsAuthenticated,)


class AdminTouristViewSet(PreventHardDeleteMixin, viewsets.ModelViewSet):
    queryset = Tourist.objects.all().order_by("id")
    serializer_class = TouristSerializer
    permission_classes = (IsReservationRole,)


class ClientTouristViewSet(viewsets.ModelViewSet):
    queryset = Tourist.objects.all().order_by("id")
    serializer_class = TouristSerializer
    permission_classes = (permissions.IsAuthenticated,)


def _adjust_availability(hotel_room_id, delta):
    if delta != 0:
        HotelRoom.objects.filter(pk=hotel_room_id).update(
            availability_count=F("availability_count") + delta
        )


class AdminHotelBookingViewSet(PreventHardDeleteMixin, viewsets.ModelViewSet):
    queryset = HotelBooking.objects.select_related(
        "hotel_room__hotel", "selling_currency", "cost_currency"
    ).order_by("check_in_date")
    serializer_class = HotelBookingSerializer
    permission_classes = (IsReservationRole,)

    def perform_create(self, serializer):
        booking = serializer.save()
        if booking.status != HotelBooking.StatusChoices.CANCELLED:
            _adjust_availability(booking.hotel_room_id, -booking.quantity)

    def perform_destroy(self, instance):
        if instance.status != HotelBooking.StatusChoices.CANCELLED:
            _adjust_availability(instance.hotel_room_id, +instance.quantity)
        instance.delete()

    def perform_update(self, serializer):
        old_qty = serializer.instance.quantity
        old_status = serializer.instance.status
        old_room_id = serializer.instance.hotel_room_id

        booking = serializer.save()

        was_active = old_status != HotelBooking.StatusChoices.CANCELLED
        is_active = booking.status != HotelBooking.StatusChoices.CANCELLED

        if old_room_id != booking.hotel_room_id:
            if was_active:
                _adjust_availability(old_room_id, +old_qty)
            if is_active:
                _adjust_availability(booking.hotel_room_id, -booking.quantity)
        else:
            if was_active and not is_active:
                _adjust_availability(booking.hotel_room_id, +old_qty)
            elif not was_active and is_active:
                _adjust_availability(booking.hotel_room_id, -booking.quantity)
            elif is_active and old_qty != booking.quantity:
                _adjust_availability(booking.hotel_room_id, -(booking.quantity - old_qty))


class ClientHotelBookingViewSet(viewsets.ModelViewSet):
    queryset = HotelBooking.objects.select_related(
        "hotel_room__hotel", "selling_currency", "cost_currency"
    ).order_by("check_in_date")
    serializer_class = HotelBookingSerializer
    permission_classes = (permissions.IsAuthenticated,)

    def perform_create(self, serializer):
        booking = serializer.save()
        if booking.status != HotelBooking.StatusChoices.CANCELLED:
            _adjust_availability(booking.hotel_room_id, -booking.quantity)

    def perform_destroy(self, instance):
        if instance.status != HotelBooking.StatusChoices.CANCELLED:
            _adjust_availability(instance.hotel_room_id, +instance.quantity)
        instance.delete()

    def perform_update(self, serializer):
        old_qty = serializer.instance.quantity
        old_status = serializer.instance.status
        old_room_id = serializer.instance.hotel_room_id

        booking = serializer.save()

        was_active = old_status != HotelBooking.StatusChoices.CANCELLED
        is_active = booking.status != HotelBooking.StatusChoices.CANCELLED

        if old_room_id != booking.hotel_room_id:
            if was_active:
                _adjust_availability(old_room_id, +old_qty)
            if is_active:
                _adjust_availability(booking.hotel_room_id, -booking.quantity)
        else:
            if was_active and not is_active:
                _adjust_availability(booking.hotel_room_id, +old_qty)
            elif not was_active and is_active:
                _adjust_availability(booking.hotel_room_id, -booking.quantity)
            elif is_active and old_qty != booking.quantity:
                _adjust_availability(booking.hotel_room_id, -(booking.quantity - old_qty))


class AdminFlightTicketViewSet(PreventHardDeleteMixin, viewsets.ModelViewSet):
    queryset = FlightTicket.objects.all().order_by("id")
    serializer_class = FlightTicketSerializer
    permission_classes = (IsReservationRole,)


class ClientFlightTicketViewSet(viewsets.ModelViewSet):
    queryset = FlightTicket.objects.all().order_by("id")
    serializer_class = FlightTicketSerializer
    permission_classes = (permissions.IsAuthenticated,)


class AdminExcursionBookingViewSet(PreventHardDeleteMixin, viewsets.ModelViewSet):
    queryset = ExcursionBooking.objects.all().order_by("tour_date")
    serializer_class = ExcursionBookingSerializer
    permission_classes = (IsReservationRole,)


class ClientExcursionBookingViewSet(viewsets.ModelViewSet):
    queryset = ExcursionBooking.objects.all().order_by("tour_date")
    serializer_class = ExcursionBookingSerializer
    permission_classes = (permissions.IsAuthenticated,)


class AdminTransferServiceViewSet(PreventHardDeleteMixin, viewsets.ModelViewSet):
    queryset = TransferService.objects.all().order_by("service_date", "id")
    serializer_class = TransferServiceSerializer
    permission_classes = (IsReservationRole,)


class ClientTransferServiceViewSet(viewsets.ModelViewSet):
    queryset = TransferService.objects.all().order_by("service_date", "id")
    serializer_class = TransferServiceSerializer
    permission_classes = (permissions.IsAuthenticated,)


class AdminExcursionServiceViewSet(PreventHardDeleteMixin, viewsets.ModelViewSet):
    queryset = ExcursionService.objects.all().order_by("-excursion_date")
    serializer_class = ExcursionServiceSerializer
    permission_classes = (IsReservationRole,)


class ClientExcursionServiceViewSet(viewsets.ModelViewSet):
    queryset = ExcursionService.objects.all().order_by("-excursion_date")
    serializer_class = ExcursionServiceSerializer
    permission_classes = (permissions.IsAuthenticated,)