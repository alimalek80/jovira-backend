from rest_framework import permissions

class IsAdminRole(permissions.BasePermission):
    """
    Full access for Superusers, Django Staff, and the General ADMIN role.
    """
    def has_permission(self, request, view):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        return user.is_superuser or user.is_staff or user.role == user.RoleChoices.ADMIN

class IsFinanceRole(permissions.BasePermission):
    def has_permission(self, request, view):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        allowed_roles = {user.RoleChoices.ADMIN, user.RoleChoices.FINANCE}
        return user.is_superuser or user.is_staff or user.role in allowed_roles

class IsInventoryRole(permissions.BasePermission):
    def has_permission(self, request, view):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        allowed_roles = {user.RoleChoices.ADMIN, user.RoleChoices.INVENTORY}
        return user.is_superuser or user.is_staff or user.role in allowed_roles

class IsReservationRole(permissions.BasePermission):
    def has_permission(self, request, view):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        allowed_roles = {user.RoleChoices.ADMIN, user.RoleChoices.RESERVATION}
        return user.is_superuser or user.is_staff or user.role in allowed_roles

class IsSalesRole(permissions.BasePermission):
    def has_permission(self, request, view):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        allowed_roles = {user.RoleChoices.ADMIN, user.RoleChoices.SALES}
        return user.is_superuser or user.is_staff or user.role in allowed_roles
    
class IsReservationEditorOrReadOnlyIfLocked(permissions.BasePermission):
    """
    Object-level permission to enforce the 'locked by finance' rule.
    - Everyone with 'IsReservationRole' can view (GET) the reservation.
    - If the reservation is LOCKED: only users with 'FINANCE' role or 'is_staff' can edit/delete it.
    - If the reservation is NOT LOCKED: users with 'RESERVATION' role can edit it.
    """
    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        if request.user.is_staff or request.user.is_superuser:
            return True
        if request.user.role == 'FINANCE':
            return True
        if request.user.role in ['RESERVATION', 'SALES']:
            if getattr(obj, 'is_locked_by_finance', False):
                return False
            return True
        return False
    